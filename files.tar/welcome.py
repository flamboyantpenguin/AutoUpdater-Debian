import pyautogui

pyautogui.alert("Welcome to AutoUpdater6.8 PUBLIC BETA", "AutoUpdater6.8 BETA", "Hello")
pyautogui.alert("Your packages are being updated do wait", "AutoUpdater6.8 BETA", "Ok")
