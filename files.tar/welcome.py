import pyautogui

pyautogui.alert("Welcome to AutoUpdater6.8", "AutoUpdater6.8", "Hello")
pyautogui.alert("Your packages are being updated do wait", "AutoUpdater6.8", "Ok")
