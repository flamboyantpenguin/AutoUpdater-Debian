import pyautogui

pyautogui.alert("Welcome to AutoUpdater6.0", "AutoUpdater6.0", "Hello")
pyautogui.alert("Your packages are being updated do wait", "AutoUpdater6.0", "Ok")
