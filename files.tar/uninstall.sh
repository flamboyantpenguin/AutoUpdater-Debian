#! /bin/bash 

log=$(date +%F_%T)

notify-send -t  05 "Starting uninstall of AutoUpdater6.8"
zenity --question --text="Are you sure?"
answer=$?
if [ $answer -eq 0 ]; then
  echo "Starting Uninstall :-("
  pass=$(zenity --password --title="AutoUpdater Uninstaller" )
  echo -n $pass | sudo -S rm ./uninstall.sh
  sudo rm $HOME/Desktop/AutoUpdater.sh
  sudo rm $HOME/AutoUpdater6.8/README.txt
  sudo rm $HOME/AutoUpdater6.8/Release_Notes.txt
  sudo mkdir old_logs
  sudo cp /etc/AutoUpdater/logs/* ./old_logs
  sudo tar -cvf logs.tar old_logs
  sudo mv logs.tar $HOME 
  sudo rm -rd /etc/AutoUpdater
  sudo rm -rd $HOME/AutoUpdater6.8
  sudo chmod 666 $HOME/logs.tar
  echo "Uninstall Finished Successfully :-("
  echo "Uninstall of AutoUpdater6.8 completed with Code 0 : Success" >> $log.txt
  sudo tar -uvf $HOME/logs.tar $log.txt
  zenity --info --text="Uninstall Finished :-(" --title="AutoUpdater Uninstaller"
else
  echo "Uninstall Canceled :-)"
fi


