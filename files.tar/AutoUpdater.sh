#! /bin/bash 

default=/etc/AutoUpdater
python3 $default/python/welcome.py
pass=$(zenity --password --title="AutoUpdater6.0" )
echo -n $pass | sudo -S bash $default/scripts/updater_main
if [ $? -ne 0 ]; then
  python3 /etc/AutoUpdater/python/error.py
fi
python3 /etc/AutoUpdater/python/end.py 
