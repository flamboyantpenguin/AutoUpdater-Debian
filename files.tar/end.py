import pyautogui

pyautogui.alert("Update Completed", "AutoUpdater6.8", "Thank you")

