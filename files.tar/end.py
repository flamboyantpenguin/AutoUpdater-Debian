import pyautogui

pyautogui.alert("Update Completed", "AutoUpdater6.8 BETA", "Thank you")

