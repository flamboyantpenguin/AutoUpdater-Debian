import pyautogui

pyatuogui.alert("Oops, there was some error. Updates did not complete. Check logs for more details", "AutoUpdater6.8 BETA")
