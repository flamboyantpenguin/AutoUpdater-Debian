#! /bin/bash

#Run this script to fetchlogs from the installed directory and put it 
#in the $HOME/AutoUpdater directory. 

date=$(date +%F_%T)
mkdir logs
pass=$(zenity --password --title="AutoUpdater6.8" --text="Please enter your system password")
echo $pass | sudo -S cp /etc/AutoUpdater/logs/* logs
sudo tar -cvf AutoUpdater_Logs.tar logs
sudo rm -rd logs
sudo chmod 666 AutoUpdater_Logs.tar 
zenity --info  --text="Logs have been fetched successfully" --title="AutoUpdater6.8"
echo "Logs fetched successfully on $date" >> /etc/AutoUpdater/logs/$date.txt
sudo chmod 666 /etc/AutoUpdater/logs/$date.txt
