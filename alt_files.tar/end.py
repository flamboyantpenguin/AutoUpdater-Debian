import pyautogui

pyautogui.alert("Update Completed", "AutoUpdater6.0 BETA", "Thank you")

