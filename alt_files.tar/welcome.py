import pyautogui

pyautogui.alert("Welcome to AutoUpdater6.0 PUBLIC BETA", "AutoUpdater6.0 BETA", "Hello")
pyautogui.alert("Your packages are being updated do wait", "AutoUpdater6.0 BETA", "Ok")
